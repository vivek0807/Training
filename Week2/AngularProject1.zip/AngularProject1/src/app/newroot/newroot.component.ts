import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newroot',
  templateUrl: './newroot.component.html',
  styleUrls: ['./newroot.component.css']
})
export class NewrootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
