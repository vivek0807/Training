const calc = require("./calc");
console.log(calc(2,3))